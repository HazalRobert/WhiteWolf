"use strict";
(() => {
  // src/x-native.ts
  var diagnosticErrors = /* @__PURE__ */ new WeakMap();
  var emptyCounts = () => ({ rootMarkers: 0, visited: 0, stores: 0, matchedActor: 0, queryFound: 0 });
  function nativeDiagnostic(error) {
    return error !== null && (typeof error === "object" || typeof error === "function") ? diagnosticErrors.get(error) : void 0;
  }
  var unavailable = (stage, counts = emptyCounts()) => {
    const error = new Error("API_UNAVAILABLE: The current X web client could not be located. Refresh the signed-in X page and reopen the extension.");
    diagnosticErrors.set(error, `stage=${stage}; rootMarkers=${counts.rootMarkers}; visited=${counts.visited}; stores=${counts.stores}; matchedActor=${counts.matchedActor}; queryFound=${counts.queryFound}`);
    throw error;
  };
  var object = (value) => value !== null && typeof value === "object" ? value : void 0;
  var queryNames = ["Viewer", "Following", "UserByRestId", "UserByScreenName"];
  function descriptorFromFactory(source, failMetadata) {
    if (source.length > 16e3) return void 0;
    const assignment = source.match(/^(?:function(?:\s+[A-Za-z_$][\w$]*)?\s*|(?:[A-Za-z_$][\w$]*|\d+)\s*)?\(\s*([A-Za-z_$][\w$]*)\s*\)\s*\{\s*(?:"use strict";\s*)?\1\.exports\s*=\s*(\{[\s\S]*\})\s*;?\s*\}$/);
    if (!assignment) return void 0;
    const text = '"(?:[^"\\\\]|\\\\.)*"';
    const list = "\\[\\s*(?:" + text + "(?:\\s*,\\s*" + text + ")*)?\\s*\\]";
    const key = (name) => "(?:" + name + '|"' + name + '")\\s*:\\s*';
    const literal = new RegExp("^\\{\\s*" + key("queryId") + '"([A-Za-z0-9_-]{8,100})"\\s*,\\s*' + key("operationName") + '"(Viewer|Following|UserByRestId|UserByScreenName)"\\s*,\\s*' + key("operationType") + '"query"\\s*,\\s*' + key("metadata") + "\\{\\s*" + key("featureSwitches") + "(" + list + ")\\s*,\\s*" + key("fieldToggles") + "(" + list + ")\\s*\\}\\s*\\}\\s*$");
    const fields = assignment[2].match(literal);
    if (!fields) return void 0;
    const readList = (value) => {
      let parsed;
      try {
        parsed = JSON.parse(value);
      } catch {
        return failMetadata();
      }
      if (!Array.isArray(parsed) || parsed.length > 200 || parsed.some((item) => typeof item !== "string" || !/^[A-Za-z0-9_]{1,160}$/.test(item)) || new Set(parsed).size !== parsed.length) return failMetadata();
      return parsed;
    };
    return { queryId: fields[1], operationName: fields[2], features: readList(fields[3]), fieldToggles: readList(fields[4]) };
  }
  function getXContext(actorId) {
    let stage = "actor";
    const counts = emptyCounts();
    const fail = () => unavailable(stage, counts);
    try {
      if (!/^[1-9][0-9]{0,19}$/.test(actorId)) return fail();
      stage = "root";
      const root = document.getElementById("react-root");
      if (!root) return fail();
      stage = "rootMarker";
      const markers = [];
      for (const key of Object.keys(root)) if (/^__react(?:Container|Fiber)\$/.test(key)) markers.push(root[key]);
      counts.rootMarkers = markers.length;
      if (!markers.length) return fail();
      const committed = (marker2) => {
        const value = object(marker2);
        return object(object(value?.stateNode)?.current) ?? object(value?.current) ?? value;
      };
      const roots = markers.map(committed);
      const queue = [...roots];
      stage = "fiberScan";
      const seen = /* @__PURE__ */ new Set();
      const stores = /* @__PURE__ */ new Map();
      const checkedStores = /* @__PURE__ */ new Set();
      const maxFibers = 25e4, maxScanMs = 1500;
      const clock = () => typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : Date.now();
      const started = clock();
      const checkTime = () => {
        const elapsed = clock() - started;
        if (!Number.isFinite(elapsed) || elapsed < 0 || elapsed > maxScanMs) unavailable("fiberTimeLimit", counts);
      };
      for (let cursor = 0; cursor < queue.length; cursor++) {
        const fiber = object(queue[cursor]);
        if (!fiber || seen.has(fiber)) continue;
        if (seen.size >= maxFibers) return unavailable("fiberNodeLimit", counts);
        seen.add(fiber);
        counts.visited = seen.size;
        if ((seen.size & 255) === 0) checkTime();
        for (const rawProps of [fiber.memoizedProps]) {
          const props = object(rawProps);
          if (!props) continue;
          for (const candidate of [props.store, object(props.value)?.store]) {
            const store = object(candidate);
            if (!store || checkedStores.has(store) || typeof store.getState !== "function" || typeof store.dispatch !== "function") continue;
            checkedStores.add(store);
            const state = object(Reflect.apply(store.getState, store, []));
            const currentActor = object(state?.session)?.user_id;
            if (typeof currentActor === "string" && /^[1-9][0-9]{0,19}$/.test(currentActor)) {
              stores.set(store, { store, actorId: currentActor });
              counts.stores = stores.size;
              if (currentActor === actorId) counts.matchedActor++;
            }
          }
        }
        for (const child of [fiber.child, fiber.sibling]) if (object(child)) queue.push(child);
      }
      checkTime();
      if (markers.some((marker2, index) => committed(marker2) !== roots[index])) return unavailable("fiberChanged", counts);
      stage = "storeSelection";
      if (stores.size !== 1) return fail();
      const selected = stores.values().next().value;
      stage = "storeActor";
      if (!selected || selected.actorId !== actorId) return fail();
      stage = "apiService";
      const service = object(Reflect.apply(selected.store.dispatch, selected.store, [(_dispatch, _getState, extra) => object(extra)?.api]));
      stage = "apiShape";
      const api = object(service?.apiClient), http = api?.client, features = api?.featureSwitches;
      stage = "storeActor";
      const freshState = object(Reflect.apply(selected.store.getState, selected.store, []));
      if (markers.some((marker2, index) => committed(marker2) !== roots[index])) return unavailable("fiberChanged", counts);
      if (object(freshState?.session)?.user_id !== actorId) return fail();
      stage = "apiShape";
      if (!http || !features || typeof http.dispatch !== "function" || typeof http.host !== "function" || !Array.isArray(http.filters) || http.filters.length > 100 || http.filters.some((filter) => typeof filter !== "function") || typeof features.getValueWithoutScribeImpression !== "function") return fail();
      stage = "webpack";
      const chunks = window.webpackChunk_twitter_responsive_web;
      if (!Array.isArray(chunks) || typeof chunks.push !== "function") return fail();
      stage = "runtime";
      let runtime;
      const marker = [["reciprocal_metadata_" + crypto.randomUUID()], {}, (require2) => {
        runtime = require2;
      }];
      try {
        chunks.push(marker);
      } finally {
        if (chunks[chunks.length - 1] === marker) chunks.pop();
      }
      if (!runtime?.m) return fail();
      stage = "factories";
      const factories = Object.values(runtime.m);
      if (factories.length > 2e4) return fail();
      stage = "queries";
      const queries = /* @__PURE__ */ Object.create(null);
      for (const factory of factories) {
        if (typeof factory !== "function") continue;
        const descriptor = descriptorFromFactory(Function.prototype.toString.call(factory), () => unavailable("metadata", counts));
        if (!descriptor) continue;
        if (queries[descriptor.operationName]) return fail();
        queries[descriptor.operationName] = descriptor;
        counts.queryFound++;
      }
      if (queryNames.some((name) => !queries[name])) return fail();
      return { http, features, queries };
    } catch (error) {
      if (nativeDiagnostic(error) !== void 0) throw error;
      return fail();
    }
  }
  function singleRequestClient(context, dispatcher) {
    let stage = "clientShape";
    try {
      const Ctor = context.http.constructor;
      if (typeof Ctor !== "function") return unavailable(stage);
      const pass = (request, next) => next(request);
      stage = "clientConstruction";
      const client = new Ctor({ host: () => context.http.host(), filters: [...context.http.filters], retryFilter: pass, errorFilter: pass, dispatcher });
      stage = "clientShape";
      if (!client || client === context.http || typeof client.dispatch !== "function") return unavailable(stage);
      return client;
    } catch (error) {
      if (nativeDiagnostic(error) !== void 0) throw error;
      return unavailable(stage);
    }
  }

  // src/x-parsers.ts
  function parseXPayload(kind, payload, context = {}) {
    const fail = (message) => {
      throw new Error(`SCHEMA: ${message}`);
    };
    const object2 = (value, path) => {
      if (!value || typeof value !== "object" || Array.isArray(value)) return fail(`${path} must be an object.`);
      return value;
    };
    const optionalObject = (value, path) => value === void 0 || value === null ? {} : object2(value, path);
    const string = (value, path) => {
      if (typeof value !== "string") return fail(`${path} must be a string.`);
      return value;
    };
    const id = (value, path) => {
      const result = string(value, path);
      if (!/^[1-9][0-9]{0,19}$/.test(result)) return fail(`${path} must be a lossless decimal user ID.`);
      return result;
    };
    const resultType = (value) => value === void 0 ? "missing" : typeof value === "string" && /^User[A-Za-z0-9]{0,60}$/.test(value) ? value : "unrecognized";
    const unwrapUserResult = (raw, path) => {
      let value = object2(raw, path);
      if (value.__typename === "UserWithVisibilityResults") {
        path += ".user";
        value = object2(value.user, path);
      }
      return { value, path };
    };
    const userResult = (raw, path = "User result") => {
      const result = unwrapUserResult(raw, path);
      if (result.value.__typename !== void 0 && result.value.__typename !== "User") {
        return fail(`Unsupported or unavailable User result; path=${result.path}; typename=${resultType(result.value.__typename)}.`);
      }
      return result.value;
    };
    const userId = (value) => {
      const legacy = optionalObject(value.legacy, "User.legacy");
      const candidates = [value.rest_id, value.id_str, legacy.id_str].filter((item) => item !== void 0);
      if (!candidates.length) return fail("User result has no string ID.");
      const ids = candidates.map((item) => id(item, "User ID"));
      if (ids.some((item) => item !== ids[0])) return fail("User result contains contradictory IDs.");
      return ids[0];
    };
    const expectId = (actual, expected) => {
      if (expected !== void 0 && actual !== id(expected, "Expected user ID")) return fail("User result does not match the expected ID.");
    };
    const firstString = (values, path, required = false) => {
      const present = values.filter((value) => value !== void 0 && value !== null);
      for (const value of present) string(value, path);
      if (!present.length) {
        if (required) return fail(`${path} is missing.`);
        return void 0;
      }
      return present[0];
    };
    const person = (raw, path = "User result") => {
      const value = userResult(raw, path);
      const legacy = optionalObject(value.legacy, "User.legacy");
      const core = optionalObject(value.core, "User.core");
      const avatar = optionalObject(value.avatar, "User.avatar");
      const bio = optionalObject(value.profile_bio, "User.profile_bio");
      const handles = [core.screen_name, legacy.screen_name, value.screen_name].filter((item) => item !== void 0 && item !== null);
      const username = firstString(handles, "User.screen_name", true);
      if (handles.some((item) => !/^[A-Za-z0-9_]{1,15}$/.test(item))) return fail("User.screen_name is invalid.");
      if (handles.some((item) => item.toLowerCase() !== username.toLowerCase())) return fail("User result contains contradictory handles.");
      const result = { id: userId(value), handle: username, name: firstString([core.name, legacy.name, value.name], "User.name", true) };
      const image = firstString([avatar.image_url, legacy.profile_image_url_https, value.profile_image_url_https], "User avatar");
      const description = firstString([bio.description, legacy.description, value.description], "User description");
      if (image && /^https:\/\//i.test(image)) result.avatar = image;
      if (description !== void 0) result.bio = description;
      return result;
    };
    const relation = (raw, path = "User result") => {
      const value = userResult(raw, path);
      const perspectives = optionalObject(value.relationship_perspectives, "User.relationship_perspectives");
      const legacy = optionalObject(value.legacy, "User.legacy");
      const boolean = (field) => {
        const values = [perspectives[field], legacy[field], value[field]].filter((item) => item !== void 0 && item !== null);
        if (values.some((item) => typeof item !== "boolean")) return fail(`User.${field} must be a boolean when present.`);
        if (values.some((item) => item !== values[0])) return fail(`User.${field} contains contradictory relationship values.`);
        return values.length ? values[0] : null;
      };
      return { id: userId(value), following: boolean("following"), followedBy: boolean("followed_by") };
    };
    const envelopeData = () => {
      const root = object2(payload, "GraphQL response");
      if (root.errors !== void 0 && (!Array.isArray(root.errors) || root.errors.length > 0) || root.error !== void 0) return fail("GraphQL returned an error envelope; partial data is not trusted.");
      return object2(root.data, "GraphQL response.data");
    };
    if (kind === "person") {
      const result = person(payload, "person");
      expectId(result.id, context.expectedId ?? context.targetId);
      return result;
    }
    if (kind === "relationFromUser") {
      const result = relation(payload, "relationFromUser");
      expectId(result.id, context.expectedId ?? context.targetId);
      return result;
    }
    if (kind === "viewer") {
      const viewer = object2(envelopeData().viewer, "data.viewer");
      const result = person(object2(viewer.user_results, "data.viewer.user_results").result, "data.viewer.user_results.result");
      expectId(result.id, context.expectedId ?? context.actorId);
      return result;
    }
    if (kind === "userGraphql") {
      const result = person(object2(envelopeData().user, "data.user").result, "data.user.result");
      expectId(result.id, context.expectedId ?? context.targetId);
      return result;
    }
    if (kind !== "followingGraphql") return fail("Unknown parser kind.");
    const rootUser = userResult(object2(envelopeData().user, "data.user").result, "data.user.result");
    if (rootUser.rest_id !== void 0 || rootUser.id_str !== void 0) expectId(userId(rootUser), context.actorId ?? context.expectedId);
    if (rootUser.timeline !== void 0 && rootUser.timeline_v2 !== void 0) return fail("Following response has ambiguous timeline containers.");
    const timelineRoot = object2(rootUser.timeline ?? rootUser.timeline_v2, "Following timeline container");
    const timeline = object2(timelineRoot.timeline, "Following timeline");
    if (!Array.isArray(timeline.instructions)) return fail("Following timeline has no explicit instructions.");
    if (timeline.instructions.length === 0) return { users: [], nextCursor: "0", relations: [] };
    const entries = /* @__PURE__ */ new Map();
    let terminatedBottom = false;
    const putEntry = (raw, replacement) => {
      const entry = object2(raw, "Timeline entry");
      const entryId = string(entry.entryId, "Timeline entry.entryId");
      if (!entryId) return fail("Timeline entry ID is empty.");
      if (replacement !== void 0) {
        if (!entries.has(replacement)) {
          const content = object2(entry.content, "Replacement entry.content");
          if (content.entryType !== "TimelineTimelineCursor" && content.__typename !== "TimelineTimelineCursor") return fail("Following user replacement has no page-local target.");
        }
        entries.delete(replacement);
      }
      if (entries.has(entryId)) return fail("Following timeline contains duplicate entry IDs.");
      entries.set(entryId, entry);
    };
    for (const [instructionIndex, raw] of timeline.instructions.entries()) {
      const instruction = object2(raw, "Timeline instruction");
      if (instruction.type === "TimelineClearCache") {
        if (context.cursor !== void 0 && context.cursor !== "-1") return fail(`Following timeline reset during pagination; type=TimelineClearCache; index=${instructionIndex}. Restart the scan.`);
        entries.clear();
        terminatedBottom = false;
      } else if (instruction.type === "TimelineAddEntries") {
        if (!Array.isArray(instruction.entries)) return fail("TimelineAddEntries.entries must be an array.");
        for (const entry of instruction.entries) putEntry(entry);
      } else if (instruction.type === "TimelineReplaceEntry") {
        const replacement = string(instruction.entry_id_to_replace, "TimelineReplaceEntry.entry_id_to_replace");
        if (!replacement) return fail("Timeline replacement ID is empty.");
        putEntry(instruction.entry, replacement);
      } else if (instruction.type === "TimelineTerminateTimeline") {
        if (!["Top", "Bottom", "TopAndBottom"].includes(instruction.direction)) return fail("Timeline termination direction is unknown.");
        if (instruction.direction === "Bottom" || instruction.direction === "TopAndBottom") terminatedBottom = true;
      } else {
        const type = typeof instruction.type === "string" && /^Timeline[A-Za-z0-9]{1,64}$/.test(instruction.type) ? instruction.type : instruction.type === void 0 ? "missing" : "unrecognized";
        return fail(`Unsupported Following timeline instruction; type=${type}; index=${instructionIndex}.`);
      }
    }
    const users = [];
    const relations = [];
    const userIds = /* @__PURE__ */ new Set();
    let unavailableCount = 0;
    let bottomCursor;
    const entryType = (value, field, path) => {
      const declared = [value[field], value.__typename].filter((item) => item !== void 0);
      if (!declared.length || declared.some((item) => typeof item !== "string") || declared.some((item) => item !== declared[0])) return fail(`${path} has no unambiguous known type.`);
      return declared[0];
    };
    for (const entry of entries.values()) {
      const content = object2(entry.content, "Timeline entry.content");
      const type = entryType(content, "entryType", "Timeline entry.content");
      if (type === "TimelineTimelineCursor") {
        if (content.cursorType !== "Top" && content.cursorType !== "Bottom") return fail("Following cursor type is unknown.");
        const value = string(content.value, "Following cursor.value");
        if (!value || value.length > 4096 || /[\s\u0000-\u001f\u007f]/.test(value)) return fail("Following cursor value is invalid.");
        if (content.cursorType === "Bottom") {
          if (bottomCursor !== void 0) return fail("Following response contains multiple Bottom cursors.");
          bottomCursor = value;
        }
      } else if (type === "TimelineTimelineItem") {
        const item = object2(content.itemContent, "Timeline itemContent");
        if (entryType(item, "itemType", "Timeline itemContent") !== "TimelineUser") return fail("Following entry is not an explicit TimelineUser.");
        if (item.promotedMetadata !== void 0 || content.promotedMetadata !== void 0) return fail("Promoted entries cannot establish a following relationship.");
        const rawUser = object2(item.user_results, "TimelineUser.user_results").result;
        const userPath = "Following.TimelineUser.user_results.result";
        const unwrapped = unwrapUserResult(rawUser, userPath);
        if (unwrapped.value.__typename === "UserUnavailable") {
          unavailableCount++;
          continue;
        }
        const user = person(rawUser, userPath);
        if (userIds.has(user.id)) return fail("Following page contains duplicate user IDs.");
        userIds.add(user.id);
        users.push(user);
        relations.push(relation(rawUser, userPath));
      } else return fail("Unsupported Following entry wrapper.");
    }
    if (bottomCursor === void 0 && !terminatedBottom) return fail("Following response has no explicit Bottom cursor or terminal page.");
    const nextCursor = terminatedBottom ? "0" : bottomCursor;
    if (nextCursor !== "0" && context.cursor !== void 0 && nextCursor === context.cursor) return fail("Following cursor did not advance.");
    return { users, nextCursor, relations, ...unavailableCount > 0 ? { unavailableCount } : {} };
  }

  // src/cursor.ts
  var isValidCursor = (value) => typeof value === "string" && value.length > 0 && value.length <= 4096 && !/[\s\u0000-\u001f\u007f]/.test(value);

  // src/x-api.ts
  function xPageRuntime(input) {
    const safeErrors = /* @__PURE__ */ new WeakSet();
    const fail = (code, message) => {
      const error = new Error(`${code}: ${message}`);
      safeErrors.add(error);
      throw error;
    };
    const record = (value) => {
      if (value === null || typeof value !== "object" || Array.isArray(value)) return fail("SCHEMA", "Expected an object.");
      return value;
    };
    const id = (value) => {
      if (typeof value !== "string" || !/^[1-9][0-9]{0,19}$/.test(value)) return fail("SCHEMA", "Missing or invalid string user ID.");
      return value;
    };
    const handle = (value) => {
      if (typeof value !== "string" || !/^[A-Za-z0-9_]{1,15}$/.test(value)) return fail("SCHEMA", "Invalid X handle.");
      return value;
    };
    const person = (raw) => {
      const value = record(raw);
      const userId = id(value.id_str);
      const username = handle(value.screen_name);
      if (typeof value.name !== "string") return fail("SCHEMA", "User name is missing.");
      const user = { id: userId, handle: username, name: value.name };
      if (typeof value.description === "string") user.bio = value.description;
      if (typeof value.profile_image_url_https === "string" && /^https:\/\//i.test(value.profile_image_url_https)) user.avatar = value.profile_image_url_https;
      return user;
    };
    const following = (raw) => {
      const value = record(raw);
      if (!Array.isArray(value.users)) return fail("SCHEMA", "Following page has no users array.");
      if (typeof value.next_cursor_str !== "string" || !/^(0|[1-9][0-9]{0,30})$/.test(value.next_cursor_str)) return fail("SCHEMA", "Following page has no valid explicit next cursor.");
      if (value.users.length === 0 && value.next_cursor_str !== "0") return fail("SCHEMA", "Empty page still has a continuation cursor.");
      const users = value.users.map(person);
      if (new Set(users.map((u) => u.id)).size !== users.length) return fail("SCHEMA", "Duplicate IDs inside a following page.");
      return { users, nextCursor: value.next_cursor_str };
    };
    const relations = (raw, requestedIds) => {
      if (!Array.isArray(raw)) return fail("SCHEMA", "Relationship lookup did not return an array.");
      requestedIds.forEach(id);
      const requested = new Set(requestedIds);
      if (requested.size !== requestedIds.length) return fail("SCHEMA", "Duplicate requested relationship IDs.");
      const found = /* @__PURE__ */ new Map();
      const allowed = /* @__PURE__ */ new Set(["following", "following_requested", "followed_by", "none", "blocking", "muting"]);
      for (const item of raw) {
        const value = record(item);
        const userId = id(value.id_str);
        if (!requested.has(userId) || found.has(userId)) return fail("SCHEMA", "Unexpected or duplicate relationship ID.");
        if (value.connections === void 0 || value.connections === null) {
          found.set(userId, { id: userId, following: null, followedBy: null });
          continue;
        }
        if (!Array.isArray(value.connections) || value.connections.some((c) => typeof c !== "string" || !allowed.has(c))) return fail("SCHEMA", "Unknown relationship connection schema.");
        const connections = value.connections;
        if (new Set(connections).size !== connections.length || connections.includes("none") && connections.length !== 1) return fail("SCHEMA", "Contradictory relationship connections.");
        found.set(userId, connections.length === 0 ? { id: userId, following: null, followedBy: null } : { id: userId, following: connections.includes("following"), followedBy: connections.includes("followed_by") });
      }
      return requestedIds.map((userId) => found.get(userId) ?? { id: userId, following: null, followedBy: null });
    };
    const relationship = (raw, actorId, targetId) => {
      const pair = record(record(raw).relationship);
      const source = record(pair.source);
      const target = record(pair.target);
      if (id(source.id_str) !== id(actorId) || id(target.id_str) !== id(targetId)) return fail("ACCOUNT_CHANGED", "Relationship response is for a different account or target.");
      if (typeof source.following !== "boolean" || typeof source.followed_by !== "boolean") return fail("SCHEMA", "Fresh relationship must contain both explicit boolean fields.");
      return { id: targetId, following: source.following, followedBy: source.followed_by };
    };
    const errorResult = (error) => ({ ok: false, error: error instanceof Error ? error.message : "NETWORK: Unknown adapter error." });
    if (input.type === "PARSE") {
      try {
        if (input.parser === "person") return { ok: true, data: person(input.payload) };
        if (input.parser === "following") return { ok: true, data: following(input.payload) };
        if (input.parser === "relations") return { ok: true, data: relations(input.payload, input.ids ?? []) };
        return { ok: true, data: relationship(input.payload, input.actorId ?? "", input.targetId ?? "") };
      } catch (error) {
        return errorResult(error);
      }
    }
    return (async () => {
      let mutationDispatched = false;
      let mutationAccepted = false;
      let writeValidUntil = 0;
      const page = window;
      let lease;
      try {
        if (location.origin !== "https://x.com") return fail("AUTH", "Open the extension from an HTTPS x.com tab.");
        const operation = input.operation;
        if (operation.kind === "cancel") {
          if (page.__reciprocalXLeaseV1?.sessionId === input.sessionId && page.__reciprocalXLeaseV1.bootId === input.bootId) page.__reciprocalXLeaseV1.cancelled = true;
          return { ok: true, data: null };
        }
        if (operation.kind === "connect") {
          if (page.__reciprocalXLeaseV1?.pendingWrite) return fail("UNCERTAIN", "A previous write is still awaiting a result. Wait and reconnect.");
          if (page.__reciprocalXLeaseV1) page.__reciprocalXLeaseV1.cancelled = true;
          page.__reciprocalXLeaseV1 = { sessionId: input.sessionId, bootId: input.bootId, cancelled: false, pendingWrite: false, relations: /* @__PURE__ */ new Map() };
        }
        lease = page.__reciprocalXLeaseV1;
        const requireLease = () => {
          if (!lease || page.__reciprocalXLeaseV1 !== lease || lease.sessionId !== input.sessionId || lease.bootId !== input.bootId || lease.cancelled) fail("CANCELLED", "This run was paused, disconnected, or replaced. Reconnect before continuing.");
        };
        const cookie = (name) => {
          const item = document.cookie.split(";").map((c) => c.trim()).find((c) => c.startsWith(`${name}=`));
          if (!item) return null;
          try {
            return decodeURIComponent(item.slice(name.length + 1));
          } catch {
            return null;
          }
        };
        const actorFromCookie = () => {
          const value = cookie("twid");
          const match = value?.match(/^"?u=([1-9][0-9]{0,19})"?$/);
          if (!match) return fail("AUTH", "Cannot verify the current X session identity.");
          return match[1];
        };
        const expectedActor = operation.kind === "connect" ? actorFromCookie() : id(operation.actorId);
        const guard = () => {
          requireLease();
          if (actorFromCookie() !== expectedActor) fail("ACCOUNT_CHANGED", "The signed-in X account changed. Reconnect and scan again.");
        };
        guard();
        if (!cookie("ct0")) return fail("AUTH", "The signed-in X session has no CSRF cookie.");
        if (operation.kind === "connect" && lease) {
          try {
            lease.context = getXContext(expectedActor);
          } catch (error) {
            return fail("API_UNAVAILABLE", `X client connection failed. Diagnostic: ${nativeDiagnostic(error) ?? "stage=contextUnknown"}.`);
          }
        }
        const context = lease?.context;
        if (!context) return fail("API_UNAVAILABLE", "The current X web client is unavailable. Refresh the X page and reconnect.");
        const feature = (key) => {
          try {
            return context.features.getValueWithoutScribeImpression(key) === true;
          } catch {
            return fail("API_UNAVAILABLE", "The current X feature settings are unavailable.");
          }
        };
        const request = async (operationName, path, params, targetId2) => {
          guard();
          const write = targetId2 !== void 0, method = write ? "POST" : "GET";
          const abort = new AbortController();
          const deadline = Date.now() + 2e4;
          let closed = false, dispatchCount = 0, timer;
          const dispatcher = async (native) => {
            if (closed || abort.signal.aborted || Date.now() >= deadline) return fail("CANCELLED", "The request deadline passed before sending.");
            guard();
            if (++dispatchCount !== 1) return fail("NETWORK", "A native filter attempted to repeat a request; repetition was blocked.");
            const url = new URL(native.uri ?? "", location.origin);
            if (!["https://x.com", "https://api.x.com"].includes(url.origin) || url.username || url.password || url.search || url.hash || ![path, `/i/api${path}`].includes(url.pathname) || native.method !== method) return fail("SCHEMA", "The native client changed the permitted request destination or method.");
            const headers = Object.fromEntries(Object.entries(native.headers ?? {}).map(([key, value]) => [key.toLowerCase(), String(value)]));
            for (const key of ["x-act-as-user-id", "x-web-auth-multi-user-id"]) if (headers[key] && headers[key] !== expectedActor) return fail("ACCOUNT_CHANGED", "The native client selected a different acting account.");
            if (!/^Bearer \S+$/.test(headers.authorization ?? "") || headers["x-csrf-token"] !== cookie("ct0")) return fail("AUTH", "The native client did not provide matching session credentials.");
            const query = new URLSearchParams();
            for (const [key, value] of Object.entries(native.params ?? {})) if (value !== void 0 && value !== null) query.set(key, String(value));
            for (const [key, value] of Object.entries(params)) if (query.get(key) !== value) return fail("SCHEMA", "Native request parameters changed unexpectedly.");
            let body;
            if (write) {
              if (Date.now() > writeValidUntil) return fail("CANCELLED", "Fresh verification expired while the native client was preparing the write.");
              if (typeof native.data !== "string" || !headers["content-type"]?.startsWith("application/x-www-form-urlencoded")) return fail("SCHEMA", "The native write was not encoded as a form.");
              body = native.data;
              const form = new URLSearchParams(body);
              if (form.getAll("user_id").length !== 1 || form.get("user_id") !== targetId2 || [...form.keys()].some((key) => key !== "user_id") || [...query.keys()].length !== 0) return fail("SCHEMA", "The native write target changed unexpectedly.");
            } else if (native.data !== void 0 && native.data !== null) return fail("SCHEMA", "A read request unexpectedly contains a body.");
            url.search = query.toString();
            guard();
            if (write) {
              if (!lease) return fail("CANCELLED", "Missing run lease.");
              lease.pendingWrite = true;
              mutationDispatched = true;
            }
            const response = await fetch(url.href, { method, credentials: "include", mode: url.origin === location.origin ? "same-origin" : "cors", cache: "no-store", redirect: "error", signal: abort.signal, headers, ...body === void 0 ? {} : { body } });
            if (write && response.ok) mutationAccepted = true;
            const responseHeaders = {};
            response.headers.forEach((value, key) => {
              responseHeaders[key.toLowerCase()] = value;
            });
            return { body: await response.text(), status: response.status, headers: responseHeaders, request: native };
          };
          try {
            const client = singleRequestClient(context, dispatcher);
            const timeout = new Promise((_resolve, reject) => {
              timer = setTimeout(() => {
                closed = true;
                abort.abort();
                const error = new Error(`${write ? "UNCERTAIN" : "NETWORK"}: ${operationName} timed out; automatic retry is disabled.`);
                safeErrors.add(error);
                reject(error);
              }, 2e4);
            });
            const response = await Promise.race([client.dispatch({ path, method, params, headers: { "content-type": write ? "application/x-www-form-urlencoded" : "application/json" }, ...write ? { data: { user_id: targetId2 } } : {}, timeout: 2e4 }), timeout]);
            if (dispatchCount !== 1) return fail("API_UNAVAILABLE", "The native client reused an existing request; fresh verification is unavailable.");
            guard();
            const detail = `${operationName} ${method} ${path}: HTTP ${response.status}; automatic retry is disabled.`;
            if (response.status === 429) return fail("RATE_LIMIT", detail);
            if (response.status === 401 || response.status === 403) return fail("AUTH", detail);
            if (response.status < 200 || response.status >= 300) return fail(write ? "UNCERTAIN" : "HTTP", detail);
            if (write) return null;
            let data;
            try {
              data = JSON.parse(response.body);
            } catch {
              return fail("SCHEMA", `${operationName} returned a non-JSON response.`);
            }
            const envelope = record(data);
            if (envelope.errors !== void 0 && (!Array.isArray(envelope.errors) || envelope.errors.length > 0) || envelope.error !== void 0) return fail("SCHEMA", `${operationName} returned an error envelope.`);
            return data;
          } catch (error) {
            if (error instanceof Error && safeErrors.has(error)) throw error;
            const diagnostic = nativeDiagnostic(error);
            if (diagnostic) return fail(write ? "UNCERTAIN" : "API_UNAVAILABLE", `X client request setup failed. Diagnostic: ${diagnostic}.`);
            return fail(write ? "UNCERTAIN" : "NETWORK", `${operationName} request failed; automatic retry is disabled.`);
          } finally {
            closed = true;
            if (timer !== void 0) clearTimeout(timer);
          }
        };
        const graphql = (name, variables, toggles = {}) => {
          const descriptor = context.queries[name];
          if (!descriptor) return fail("API_UNAVAILABLE", `The current X client has no ${name} query metadata.`);
          let features;
          try {
            features = Object.fromEntries(descriptor.features.map((key) => [key, context.features.getValueWithoutScribeImpression(key) === true]));
          } catch {
            return fail("API_UNAVAILABLE", "The current X query feature settings are unavailable.");
          }
          const fieldToggles = Object.fromEntries(descriptor.fieldToggles.filter((key) => Object.hasOwn(toggles, key)).map((key) => [key, toggles[key]]));
          return request(name, `/graphql/${descriptor.queryId}/${name}`, { variables: JSON.stringify(variables), ...descriptor.features.length ? { features: JSON.stringify(features) } : {}, ...Object.keys(fieldToggles).length ? { fieldToggles: JSON.stringify(fieldToggles) } : {} });
        };
        const parse = (...args) => {
          try {
            return parseXPayload(...args);
          } catch (error) {
            return fail("SCHEMA", error instanceof Error && error.message.startsWith("SCHEMA: ") ? error.message.slice(8) : "The X response schema was not recognized.");
          }
        };
        const verify = async () => {
          const account = parse("viewer", await graphql("Viewer", { withCommunitiesMemberships: feature("c9s_enabled") }, { isDelegate: false, withAuxiliaryUserLabels: feature("blue_business_multi_affiliates_ui_enabled") }));
          if (account.id !== expectedActor) return fail("ACCOUNT_CHANGED", "The verified account differs from this run.");
          guard();
          return { id: account.id, handle: account.handle, name: account.name };
        };
        const readUser = async (targetId2) => {
          const data = await graphql("UserByRestId", { userId: id(targetId2) });
          const target = parse("userGraphql", data, { targetId: targetId2 });
          const raw = record(record(record(data).data).user).result;
          return { person: target, relation: parse("relationFromUser", raw, { targetId: targetId2 }) };
        };
        const freshRelation = async (targetId2) => (await readUser(targetId2)).relation;
        const resolve = async (username) => parse("userGraphql", await graphql("UserByScreenName", { screen_name: handle(username), withGrokTranslatedBio: false }, { withAuxiliaryUserLabels: feature("blue_business_multi_affiliates_ui_enabled"), withPayments: false }));
        if (operation.kind === "connect" || operation.kind === "identity") return { ok: true, data: await verify() };
        guard();
        if (operation.kind === "following") {
          if (!isValidCursor(operation.cursor)) return fail("SCHEMA", "Invalid input cursor.");
          const result = parse("followingGraphql", await graphql("Following", { userId: expectedActor, count: 20, includePromotedContent: false, withGrokTranslatedBio: false, ...operation.cursor === "-1" ? {} : { cursor: operation.cursor } }), { actorId: expectedActor, cursor: operation.cursor });
          for (const relation of result.relations) lease.relations.set(relation.id, relation);
          return { ok: true, data: { users: result.users, nextCursor: result.nextCursor, relations: result.relations, ...result.unavailableCount ? { unavailableCount: result.unavailableCount } : {} } };
        }
        if (operation.kind === "relations") {
          if (operation.ids.length < 1 || operation.ids.length > 100) return fail("SCHEMA", "Relationship lookup requires 1\u2013100 IDs.");
          operation.ids.forEach(id);
          if (new Set(operation.ids).size !== operation.ids.length) return fail("SCHEMA", "Duplicate requested relationship IDs.");
          return { ok: true, data: operation.ids.length === 1 ? [await freshRelation(operation.ids[0])] : operation.ids.map((userId) => lease.relations.get(userId) ?? { id: userId, following: null, followedBy: null }) };
        }
        if (operation.kind === "resolve") return { ok: true, data: await resolve(operation.handle) };
        if (operation.kind === "prepareUnfollow") {
          await verify();
          const fresh = await readUser(operation.targetId), target = fresh.person;
          if (target.id !== operation.targetId) return fail("SCHEMA", "Target lookup returned a different user ID.");
          if (target.id === expectedActor) return fail("SKIPPED", "The target is the signed-in account.");
          const before = fresh.relation;
          if (before.following !== true || before.followedBy !== false) return fail("SKIPPED", "Fresh verification no longer identifies this account as a non-follower.");
          if (!lease) return fail("CANCELLED", "The operation was cancelled.");
          const nonce = crypto.randomUUID();
          lease.proof = { nonce, actorId: expectedActor, target, at: Date.now(), used: false };
          return { ok: true, data: { target, proofId: nonce } };
        }
        let targetId;
        if (operation.kind === "unfollow") {
          const proof = lease?.proof;
          if (!proof || proof.nonce !== operation.proofId || proof.used || proof.actorId !== expectedActor || proof.target.id !== operation.targetId || Date.now() - proof.at > 15e3) return fail("CANCELLED", "Fresh verification expired or is missing. No write was sent.");
          proof.used = true;
          targetId = proof.target.id;
          writeValidUntil = proof.at + 15e3;
        } else {
          await verify();
          const author = await resolve("MagicalStocker");
          if (author.handle.toLowerCase() !== "magicalstocker") return fail("SCHEMA", "Author lookup returned another handle.");
          targetId = author.id;
          if (targetId === expectedActor) return fail("SKIPPED", "The target is the signed-in account.");
          const before = await freshRelation(targetId);
          if (before.following === true) return { ok: true, data: { actorId: expectedActor, targetId, following: true, verified: true } };
          if (before.following !== false) return fail("SCHEMA", "The author relationship could not be confirmed.");
          writeValidUntil = Date.now() + 15e3;
        }
        guard();
        const action = operation.kind === "unfollow" ? "destroy" : "create";
        await request(action, `/1.1/friendships/${action}.json`, {}, targetId);
        await verify();
        const after = await freshRelation(targetId);
        const desiredFollowing = operation.kind === "followAuthor";
        if (after.following !== desiredFollowing) return fail("UNCERTAIN", "A fresh read did not confirm the requested relationship state. Stop and inspect before any retry.");
        return { ok: true, data: { actorId: expectedActor, targetId, following: desiredFollowing, verified: true } };
      } catch (error) {
        const message = error instanceof Error && safeErrors.has(error) ? error.message : "NETWORK: The page adapter failed; native request details were not exported.";
        if (mutationAccepted || mutationDispatched && !/^(RATE_LIMIT|AUTH|UNCERTAIN):/.test(message)) return { ok: false, error: `UNCERTAIN: A write may have completed; verification was interrupted. ${message}` };
        return { ok: false, error: message };
      } finally {
        if (lease && mutationDispatched) lease.pendingWrite = false;
      }
    })();
  }

  // src/x-page.ts
  window.__reciprocalXRuntimeV2 = xPageRuntime;
})();
